## aew-backend contains the backend programs for AEW system.
## AEW: <http://aew.dianpingoa.com/>

### Installation
1. It's written in **Python 2.6/2.7** on a Linux system.
  
2. Please install **MySQL driver** for python from:
	[http://dev.mysql.com/downloads/connector/python/](http://dev.mysql.com/downloads/connector/python/)
	It uses the mysql connector to interact with MySQL DB.
  
3. Please install **web.py** 0.37 version and MySQLdb lib.
	e.g. use `easy_install web.py` to install web.py
	[http://http://webpy.org/](http://http://webpy.org/) 
	e.g. use `easy_install MySQL-python` to install MySQLdb
	or, download and install MySQLdb from the following link:
	[http://sourceforge.net/projects/mysql-python/](http://sourceforge.net/projects/mysql-python/)
    It uses web.py as the web framework for RESTful APIs and web pages.
    
  
  
### repo: git@code.dianpingoa.com:auto/aew-backend.git
[http://code.dianpingoa.com/auto/aew-backend](http://code.dianpingoa.com/auto/aew-backend)
command: `git clone git@code.dianpingoa.com:auto/aew-backend.git`
### Author: Jay <yongjie.ren@dianping.com>
