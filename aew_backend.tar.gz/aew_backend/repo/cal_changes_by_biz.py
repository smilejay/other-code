#!/usr/bin/python
# -*- coding: utf-8 -*-

""" calculate code line changes for a biz line

Copyright (C) 2013 Jay <yongjie.ren@dianping.com>
"""
import sys
from locale import str
sys.path.append("..")
import lib.db_connection as db_connection
import lib.date_utils as date_utils
import lib.biz_line as biz_line
import lib.repo as repo
import time
import getopt

from datetime import datetime,timedelta
from calendar import mdays

from config import aew_db_config, base_dir, force_renew, suffix
from cal_changes_per_repo import cal_by_month, cal_total_lines_using_find_wc

reload(sys)
sys.setdefaultencoding('utf-8')

# biz IDs in biz table
biz_ids = biz_line.get_biz_id_list()
biz_ids.append(12)  # add 'auto' group when calculate code changes

def monthly_changes_by_biz(biz_id, month):
    """monthly code line changes
    @biz_id --- the id for a biz line
    @month --- a month to query  (e.g. 2013-09) """

    total = 0
    add = 0
    delete = 0
    date = datetime.strptime(month, "%Y-%m").date()
    date_next_month = date + timedelta(days=mdays[date.month])
    date = date.isoformat()
    renew = 1
    
    biz_id = int(biz_id)

    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    sql1 = "SELECT line_changes, line_add, line_del, modify_time FROM monthly_changes " \
            + "WHERE month='%s' AND biz_id='%d' LIMIT 1" % (date, biz_id)
    cursor.execute(sql1)
    #print sql1
    row = cursor.fetchone()
    if row != None:
        modify_time = row[3]
        if datetime.today().date()>date_next_month and force_renew != 1 \
	       and modify_time.date()>date_next_month:  # no need to update the data
            total = row[0]
            add = row[1]
            delete = row[2]
            renew = 0
    if renew != 0:   # only if renew != 0 , it should update the data of code line changes
        sql2 = "SELECT p_path, ns_path FROM repo_biz_map WHERE biz_id=%d AND is_enable='Y'" % biz_id
        cursor.execute(sql2)
        #print sql2
        rows = cursor.fetchall()
        for (i, j) in rows: # calculate the sum for all the repos in a biz line
            mydir = base_dir + '/' + j + '/' + i + suffix
#            print mydir, month
            (t, a, d) = cal_by_month(mydir, month)
#            print (t, a, d)
               
            sql3 = "SELECT COUNT(*) FROM monthly_changes_repo WHERE p_path='" + i \
                       + "' AND ns_path='" + j + "' AND month='" + date + "'"
            #print sql3
            cursor.execute(sql3)
            row3 = cursor.fetchone()
            if row3[0] == 0:  # insert monthly changes for a repo
                sql_ins_repo = "INSERT INTO monthly_changes_repo (month, p_path, ns_path, \
                             line_changes, line_add, line_del, create_time, modify_time) \
                             VALUES ('" + date + "', '" + i + "', '" + j + "', '" + str(t) \
                             + "', '" + str(a) + "', '" + str(d) + "', now(), now())"
                #print sql_ins_repo
                cursor.execute(sql_ins_repo)
            elif row3[0] == 1:  # update monthly changes for a repo
                sql_upd_repo = "UPDATE monthly_changes_repo SET line_changes='" + str(t) + \
                           "', line_add='" + str(a) + "', line_del='" + str(d) + "', modify_time=now()" \
                            + "WHERE month='" + date + "' AND p_path='" + i + "' AND ns_path='"\
                            + j + "'"
                #print sql_upd_repo
                cursor.execute(sql_upd_repo)
            else:
                print "ERROR! There should NOT more than 1 record for each repo."
            total += t
            add += a
            delete += d

        sql4 = "SELECT COUNT(*) FROM monthly_changes WHERE biz_id='%d' AND month='%s'" % (biz_id, date)
        #print sql4
        cursor.execute(sql4)
        row4 = cursor.fetchone()
        if row4[0] == 0: # insert new record for monthly changes for a biz line
            sql_ins = "INSERT INTO monthly_changes (month, biz_id, line_changes, line_add, \
                       line_del, create_time, modify_time) \
                       VALUES ('" + date + "', '" + str(biz_id) + "', '" + str(total) + "', '" + str(add) \
                       + "', '" + str(delete) + "', now(), now())"
            #print sql_ins
            cursor.execute(sql_ins)
        elif row4[0] == 1:  # update the record for monthly changes for a biz line
            sql_upd = "UPDATE monthly_changes SET line_changes='" + str(total) + "', line_add='" \
                       + str(add) + "', line_del='" + str(delete) + "', modify_time=now() WHERE month='" \
                       + date + "' AND biz_id='" + str(biz_id) + "'"
            #print sql_upd
            cursor.execute(sql_upd)
        else:
            print "ERROR! There should NOT more than 1 record for each biz line."

    db_connection.commit(cnx)  # need to commit it after doing DB changes
    cursor.close()
    db_connection.close_db(cnx)
#    print (total, add, delete)
    return (total, add, delete)

def monthly_changes_all_biz(month):
    '''
    show/calculate the code changes of recent 3 months.
    '''
    print 'GitLab中的各业务线代码行数变化按月统计：'
    start = date_utils.get_month_before_last_month(month)
    end = month
    month_list = date_utils.list_months(start, end)
    for month in month_list:
        print "month=" + month
        for biz_id in biz_ids:
            (total, add, delete) = monthly_changes_by_biz(biz_id, month)
            biz_name = biz_line.get_name_by_id(biz_id)
            print '%s:  add=%s,  del=%s' % (biz_name, str(add), str(delete))

def show_changes():
    month_list = date_utils.list_months('2013-07', '2013-09')

    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()

    for month in month_list:
        print "-----------------------------------------------------"
        print "month=" + month
        for biz_id in biz_ids:
            if force_renew == 1:
                monthly_changes_by_biz(biz_id, month)
                time.sleep(1)

            month_01 = month + "-01"
            sql = "SELECT line_changes, line_add, line_del FROM monthly_changes WHERE "\
                    + "month='" + str(month_01) + "' AND biz_id='" + str(biz_id) + "';"
            cursor.execute(sql)
            row = cursor.fetchone()
            biz_name = biz_line.get_name_by_id(biz_id)
            print '%s: add=%s, del=%s ' % (biz_name, str(row[1]), str(row[2]))

# calculate total code lines of all the test repos
def cal_total_lines_test_repo():
    renew = 1

    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    for (j, i) in repo.get_test_repos():
        sql = "SELECT total_lines FROM total_lines_repo WHERE ns_path='%s' AND p_path='%s'" % (j, i)
        cursor.execute(sql)
        #print sql
        row = cursor.fetchone()
        if row != None and force_renew != 1:  # no need to update the data
            renew = 0
        if renew != 0:   # only if renew != 0 , it should update the data of total code lines
            mydir = base_dir + '/' + j + '/' + i + suffix
#             print mydir
            t = cal_total_lines_using_find_wc(mydir)
            t = int(t) if t else 0
             
            if not row:  # insert new data about total lines for a repo
                sql_ins_repo = "INSERT INTO total_lines_repo (p_path, ns_path, total_lines, create_time, modify_time) "\
                                + "VALUES ('%s', '%s', %d, now(), now())" % (i, j, t)
#                 print sql_ins_repo
                cursor.execute(sql_ins_repo)
            else:  # update the data about toal lines for a repo
                sql_upd_repo = "UPDATE total_lines_repo SET total_lines='%d', modify_time=now() " % t\
                                + "WHERE p_path='%s' AND ns_path='%s'" % (i, j)
                #print sql_upd_repo
                cursor.execute(sql_upd_repo)

    db_connection.commit(cnx)  # need to commit it after doing DB changes
    cursor.close()
    db_connection.close_db(cnx)

# calculate total code lines of a biz
def cal_total_lines_by_biz(biz_id):
    total = 0
    renew = 1

    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    sql1 = "SELECT total_lines FROM total_lines WHERE biz_id='%d' LIMIT 1" % biz_id
    cursor.execute(sql1)
    #print sql1
    row = cursor.fetchone()
    if row != None and force_renew != 1:  # no need to update the data
        total = row[0]
        renew = 0
    if renew != 0:   # only if renew != 0 , it should update the data of total code lines
        sql2 = "SELECT p_path, ns_path FROM repo_biz_map WHERE biz_id='%d' AND is_enable='Y'" % biz_id
        cursor.execute(sql2)
        #print sql2
        rows = cursor.fetchall()
        for (i, j) in rows: # calculate the total code lines for all the repos in a biz line
            mydir = base_dir + '/' + j + '/' + i + suffix
#            print mydir
#            t = cal_total_lines_using_git(mydir)
            t = cal_total_lines_using_find_wc(mydir)
            t = int(t) if t else 0
               
            sql3 = "SELECT COUNT(*) FROM total_lines_repo WHERE p_path='%s' AND ns_path='%s'" % (i, j)
            #print sql3
            cursor.execute(sql3)
            row3 = cursor.fetchone()
            if row3[0] == 0:  # insert total lines for a repo
                sql_ins_repo = "INSERT INTO total_lines_repo (p_path, ns_path, total_lines, create_time, modify_time) "\
                            + "VALUES ('%s', '%s', %d, now(), now())" % (i, j, t)
                #print sql_ins_repo
                cursor.execute(sql_ins_repo)
            elif row3[0] == 1:  # update total lines for a repo
                sql_upd_repo = "UPDATE total_lines_repo SET total_lines='%d', modify_time=now() " % t\
                            + "WHERE p_path='%s' AND ns_path='%s'" % (i, j)
                #print sql_upd_repo
                cursor.execute(sql_upd_repo)
            else:
                print "ERROR! There should NOT more than 1 record for each repo."
            total += t

        sql4 = "SELECT COUNT(*) FROM total_lines WHERE biz_id='%d'" % biz_id
        #print sql4
        cursor.execute(sql4)
        row4 = cursor.fetchone()
        if row4[0] == 0: # insert new record for total lines for a biz line
            sql_ins = "INSERT INTO total_lines (biz_id, total_lines, create_time, modify_time) " \
                      + "VALUES ('%d', '%d', now(), now())" % (biz_id, total)
            #print sql_ins
            cursor.execute(sql_ins)
        elif row4[0] == 1:  # update the record for monthly changes for a biz line
            sql_upd = "UPDATE total_lines SET total_lines='%d', modify_time=now() " % total \
                       +"WHERE biz_id='%d'" % biz_id
            #print sql_upd
            cursor.execute(sql_upd)
        else:
            print "ERROR! There should NOT more than 1 record for each biz line."

    db_connection.commit(cnx)  # need to commit it after doing DB changes
    cursor.close()
    db_connection.close_db(cnx)
#    print total

# show total code lines of all biz lines
def show_total_lines():
    today = datetime.today().date().isoformat()
    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    
    print '-------------------------------------------------------------------'
    for biz_id in biz_ids:
        if force_renew == 1:
            cal_total_lines_by_biz(biz_id)
            time.sleep(1)

        sql1 = "SELECT name FROM biz WHERE id='%d'" % biz_id
        sql2 = "SELECT total_lines FROM total_lines WHERE biz_id='%d'" % biz_id
        cursor.execute(sql1)
        row = cursor.fetchone()
        biz_name = row[0]
        cursor.execute(sql2)
        row = cursor.fetchone()
        print  "%s: total lines=%d    --- %s" % (biz_name, row[0], today)
    print '-------------------------------------------------------------------'

def yearly_changes_all_biz(year):
    print('yearly git code changes')

# FIXME
def usage():
    print 'print usage'

# main function
def main():
    month =''
    year = ''
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'hm:y:', ['help', 'month=', 'year='])
    except getopt.GetoptError as err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    for opt, arg in opts:
        if opt in ('-h', '--help'):
            usage()
            sys.exit(0)
        elif opt in ('-m', '--month'):
            month = arg
        elif opt in ('-y', '--year'):
            year = arg
        else:
            assert False, "unhandled option"
    
    if month:
        monthly_changes_all_biz(month)
    elif year:
        yearly_changes_all_biz(year)
    else:
        show_total_lines()   

if __name__ == '__main__':
    main()