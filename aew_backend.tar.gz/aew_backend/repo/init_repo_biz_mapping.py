#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
sys.path.append("..")
import lib.db_connection as db_connection
from config import gitlab_db_config,aew_db_config

# biz line and its git repo group  (1, 2, ... , 10 is the biz ID in biz table)
biz_repo_dict={1:['android', 'geoinfo', 'group', 'info', 'it-search', 'mango', 
                  'mobile', 'mobile-static', 'mobile-optimus', 'piccenter', 
                  'shop', 'shoppic', 'tomato', 'tomato-lab', 'user', 'activity'],
               2:['shop-business'],
               3:['hotel', 'apple'],
               4:['open'],
               5:['rs'],
               6:['takeaway'],
               7:['adwords', 'midas', 'promo'],
               8:['paycenter', 'tuangou', 'mcard', 'ba-crm', 'ba-mobile', 'ba-pc'],
               9:['account', 'arts-repo', 'dps-repo', 'piccenter-cloud'],
               10:['ba', 'ba_finance', 'ba-csc', 'ba-es', 'ba-vat'],
               11:['arch'],
               12:['auto']
              }

# for some test repos :  key->group name, value->project name. 
# when value equals 'all', it includes the whole group. 
test_repo_dict = {'auto':['all']}

# clear old data in repo_biz_map table and set its AUTO_INCREMENT to 1
def clear_repo_biz_map():
    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    sql1 = 'DELETE FROM repo_biz_map;'
    sql2 = 'ALTER TABLE repo_biz_map AUTO_INCREMENT = 1;'
    cursor.execute(sql1)
    cursor.execute(sql2)
    db_connection.commit(cnx)
    cursor.close()
    db_connection.close_db(cnx)

# only for the initialization about biz line and repo mapping 
def init_biz_repo_mapping():
    cnx1 = db_connection.connect_db(**gitlab_db_config)
    if cnx1 == None:
        print "GitLab DB connection ERROR!!"
        sys.exit(1)
    cursor1 = cnx1.cursor()
    cnx2 = db_connection.connect_db(**aew_db_config)
    if cnx2 == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor2 = cnx2.cursor()
    for key in biz_repo_dict.keys():
        for ns_path in biz_repo_dict[key]:
            # get some data from GitLab DB
            sql1 = "SELECT p.path, n.path, p.id, n.id FROM projects AS p, namespaces AS n \
                    WHERE p.public=1 AND n.path='" + ns_path + "' AND p.namespace_id=n.id;"
            cursor1.execute(sql1)
            rows = cursor1.fetchall()
            for row in rows:
                # insert the data into our AEW DB
                sql2 = "INSERT INTO repo_biz_map(p_path, ns_path, p_id, ns_id, biz_id, create_time, modify_time, is_enable) \
                        VALUES ('" + row[0] + "', '" + row[1] + "', " + str(row[2]) + ", " + str(row[3]) + ", " \
                        + str(key) + ", now(), now(), 'Y');"
                cursor2.execute(sql2)

    cursor1.close()
    db_connection.close_db(cnx1)
    db_connection.commit(cnx2)
    cursor2.close()
    db_connection.close_db(cnx2)

# disable some test repos whose name contains 'test' keywords    
def disable_test_repo():
    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    sql = "UPDATE repo_biz_map SET is_enable='N' WHERE p_path LIKE '%test%' AND ns_path!='auto';"
    cursor.execute(sql)
    db_connection.commit(cnx)
    cursor.close()
    db_connection.close_db(cnx)

# some ugly fix for some garbage repos
def disable_garbage_repo():
    repos = [['hotel', 'shop-hotel-beans'], ['hotel', 'shop-hotel-server'], ['hotel', 'shop-otahotel-web'], 
             ['rs', 'rs-shop-remote']]
    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    for repo in repos:
        sql = "UPDATE repo_biz_map SET is_enable='N' WHERE ns_path='%s' AND p_path='%s'" % (repo[0], repo[1])
        cursor.execute(sql)
        db_connection.commit(cnx)
    cursor.close()
    db_connection.close_db(cnx)

# init some test repos
def init_test_repo():
    STR_ALL = 'all'  # use all repos in the group
    cnx1 = db_connection.connect_db(**gitlab_db_config)
    if cnx1 == None:
        print "GitLab DB connection ERROR!!"
        sys.exit(1)
    cursor1 = cnx1.cursor()
    cnx2 = db_connection.connect_db(**aew_db_config)
    if cnx2 == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor2 = cnx2.cursor()
    for group in test_repo_dict:
        if test_repo_dict[group][0] == STR_ALL:
            # get some data from GitLab DB
            sql1 = "SELECT p.path, n.path, p.id, n.id FROM projects AS p, namespaces AS n " \
               + "WHERE p.public=1 AND n.path='%s' AND p.namespace_id=n.id;" % group
            cursor1.execute(sql1)
            rows = cursor1.fetchall()
        else:
            # get some data from GitLab DB
            sql1 = "SELECT p.path, n.path, p.id, n.id FROM projects AS p, namespaces AS n " \
               + "WHERE p.public=1 AND n.path='%s' AND p.path='%s' AND p.namespace_id=n.id;" % (group, test_repo_dict[group])
            cursor1.execute(sql1)
            rows = cursor1.fetchall()
            
        # insert the data into our AEW DB
        for row in rows:
            sql2 = "INSERT INTO test_repo(p_path, ns_path, p_id, ns_id, create_time, modify_time, is_enable) VALUES "\
                   + "('%s', '%s', '%s', '%s', now(), now(), 'Y')" % (row[0], row[1], str(row[2]), str(row[3]))
            cursor2.execute(sql2)    
        
    cursor1.close()
    db_connection.close_db(cnx1)
    db_connection.commit(cnx2)
    cursor2.close()
    db_connection.close_db(cnx2)

if __name__ == '__main__':
    clear_repo_biz_map()
    init_biz_repo_mapping()
    disable_test_repo()
    init_test_repo()
    disable_garbage_repo()
#    print biz_repo_dict
