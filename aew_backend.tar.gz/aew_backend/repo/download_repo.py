#!/usr/bin/python
""" Download repos from Gitlab

To get repo list from GitLab <http://code.dianingoa.com>
Copyright (C) 2013 Jay <yongjie.ren@dianping.com>
"""

import os
import time
import sys
sys.path.append("..")
import lib.db_connection as db_connection

from config import aew_db_config, base_dir, base_url, gitlab_db_config, suffix

# download repo from code.dianingoa.com
def download_repo():
    os.chdir(base_dir)

    cnx = db_connection.connect_db(**gitlab_db_config)
    if cnx == None:
        print "DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    #sql = "select id, namespace_id from projects where public=1 and name='dpindex-web' limit 1"
    group_project_sql = "select n.path, p.path from projects as p, namespaces as n \
                         where p.public=1 and n.type='Group' and p.namespace_id=n.id \
                         order by n.path;"
    cursor.execute(group_project_sql)
    for (group, project) in cursor:
        time.sleep(1)
        url = base_url + ':' + group + '/' + project + suffix
        group_dir = base_dir + '/' + group
        if not os.path.exists(group_dir):
            os.makedirs(group_dir)
        os.chdir(group_dir)
        repo_dir = group_dir + '/' + project + suffix
        if not os.path.exists(repo_dir):
            print('git clone ' + url + ' ' + repo_dir)
            os.system('git clone ' + url + ' ' + repo_dir)
        else:
            os.chdir(repo_dir)
            os.system('git pull -f')
#        print (url)
#        print ("id=%-8s; group_id=%-8s" % (group, project))
    cursor.close()
    db_connection.close_db(cnx)

# only for testing
if __name__ == "__main__":
    download_repo()
