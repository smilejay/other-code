#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Oct 22, 2013
 
@author: jay <yongjie.ren@dianing.com>
@summary: check the repo records in repo_biz_map table;
          if any repo doesn't exist in remote gitlab DB or not public
          or doesn't exist on local disk, it will alert some warning messages. 
'''

import sys
sys.path.append("..")
import os
import lib.db_connection as db_connection
from config import base_dir, aew_db_config, gitlab_db_config, suffix
from lib.email_utils import send_email

# three types of failed scenarios
msg1 = "%s: %s/%s.git exists in repo_biz_map but doesn't exist in gitlab."
msg2 = "%s: %s/%s.git exists in repo_biz_map but it's not public in gitlab."
msg3 = "%s: %s/%s.git exists in both repo_biz_map and gitlab, but doesn't exist in local %s" 

# set from_addr, to_addrs, subject, body of the warning email
from_addr = '任永杰 <yongjie.ren@dianping.com>'
#to_addrs = ['QA-业务负责人 <QA-Leads@dianping.com>', '任永杰 <yongjie.ren@dianping.com>']
to_addrs = ['任永杰 <yongjie.ren@dianping.com>']
subject = 'repo warning from AEW system'
body = ''  # you should use HTML body.

def check_aew_repo():
    """ Check AEW repo records comparing with the GitLab DB and Local disk.
        If any abnormal issues, it will send email to laert an warning.
        Note that any repo name with 'test' as a substring will be excluded.
    """
    cnx1 = db_connection.connect_db(**aew_db_config)
    if cnx1 == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor1 = cnx1.cursor()
    cnx2 = db_connection.connect_db(**gitlab_db_config)
    if cnx2 == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor2 = cnx2.cursor()
    
    msg_list = []
    sql1 = "SELECT p_path, ns_path, biz_id FROM repo_biz_map WHERE is_enable='Y'"
    cursor1.execute(sql1)
    rows = cursor1.fetchall()
    for row in rows:
        # exclude project name with 'test' string 
        if row[0].lower().find('test') != -1:
            continue
        sql2 = "SELECT name FROM biz WHERE id=%d LIMIT 1" % int(row[2])
        cursor1.execute(sql2)
        name_row = cursor1.fetchone()
        msg = check_repo_on_gitlab(cursor2, row[0], row[1], name_row[0])
        if msg != None:
            msg_list.append(msg)
        else:
            msg = check_repo_in_local_disk(row[0], row[1], name_row[0])
            if msg != None:
                msg_list.append(msg)
    
    # construct and send email
    if len(msg_list) != 0:
        prefix_msg = "Hi All,<br /n>This email is automatically sent by AEW monitor system. <br /n> \
-----------------------------------------------------------------------------------------------<br /n>"
        suffix_msg = """<br /n>
-----------------------------------------------------------------------------------------------<br /n> 
You might want to contact the email sender or update the following spreadsheet: <br /n>
<a href="https://docs.google.com/a/dianping.com/spreadsheet/ccc?key=0Aj5WReusSet3dHg1WmoxTEcxX25ES1JuX1pNWVctcXc">
https://docs.google.com/a/dianping.com/spreadsheet/ccc?key=0Aj5WReusSet3dHg1WmoxTEcxX25ES1JuX1pNWVctcXc </a><br /n>
<br /n>
--<br /n> 
Best Regards,<br /n>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;任永杰 <yongjie.ren@dianping.com>
"""
        body = '<br />'.join(msg_list)
        body = prefix_msg + body + suffix_msg.decode('utf-8')
#         print body
        send_email(from_addr, to_addrs, subject, body)
    
    cursor1.close()
    cursor2.close()
    db_connection.close_db(cnx1)
    db_connection.close_db(cnx2)

def check_repo_in_local_disk(p_path, ns_path, biz_name):
    """check AEW repo records with local disk. 
        it should be called only after checking with remote GitLab DB.
        
        @return: msg. None if the git repo dir exists, not None otherwise.
        
        it requires the following 3 parameters.
        @p_path: project path
        @ns_pah: project group (namespace) path
        @biz_name: the name of the biz line which owns the repo
    """
    
    msg = None
    repo_dir = '%s/%s/%s%s' % (base_dir, ns_path, p_path, suffix)
    if not os.path.exists(repo_dir):
        msg = msg3 % (biz_name, ns_path, p_path, repo_dir)
    return msg

def check_repo_on_gitlab(cursor, p_path, ns_path, biz_name):
    """check AEW repo records with GitLab. 
    
        @return: msg. None if the git repo dir exists, not None otherwise.
        
        it requires the following 4 parameters.
        @cursor: the DB connection cursor of the GitLab DB
        @p_path: project path
        @ns_pah: project group (namespace) path
        @biz_name: the name of the biz line which owns the repo
    """
    
    msg = None
    sql1 = "SELECT count(*) FROM projects WHERE public=1 AND path='%s' AND " % p_path \
          + "namespace_id=(SELECT id FROM namespaces WHERE path='%s');" % ns_path
    cursor.execute(sql1)
    row1 = cursor.fetchone()
    if row1[0] == 0:
        sql2 = "SELECT count(*) FROM projects WHERE path='%s' AND " % p_path \
               + "namespace_id=(SELECT id FROM namespaces WHERE path='%s');" % ns_path
        cursor.execute(sql2)
        row2 = cursor.fetchone()
        if row2[0] == 0:
            msg = msg1 % (biz_name, ns_path, p_path)
        else:
            msg = msg2 % (biz_name, ns_path, p_path)
    return msg

if __name__ == '__main__':
    check_aew_repo()