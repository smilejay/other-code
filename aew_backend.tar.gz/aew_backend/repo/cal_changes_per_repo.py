#!/usr/bin/python
""" calculate code line changes in a repo by month
Copyright (C) 2013 Jay <yongjie.ren@dianping.com>
"""
import os
from datetime import datetime,timedelta
from calendar import mdays
import sys
sys.path.append("..")
import lib.exec_cmds as exec_cmds
from config import suffix


suffix_list = ['java', 'xml', 'py', 'cs', 'm', 'sh', 'php', 'rb']

# calculate code changes by month (e.g. 2013-08)
def cal_by_month(mydir, month):
    if not os.path.exists(mydir):
        print("Error: %s doesn't exist." % mydir)
        return None
    saved_dir = os.getcwd()
    os.chdir(mydir)
    start_datetime = datetime.strptime(month, "%Y-%m")
    #print ("start=" + start)
    end_datetime = start_datetime + timedelta(days=mdays[start_datetime.month])
    start_date = start_datetime.date().isoformat()
    end_date = end_datetime.date().isoformat()

    shortstat = exec_cmds.getpipeoutput(['git log --no-merges --shortstat \
        --after="%s 00:00:00" --before="%s 00:00:00"' % (start_date, end_date)])
    #print shortstat
    # start/end are the first and last commits during the datedelta in the repo
    (start, end) = get_commits_from_shortstat(shortstat)
    
    diff = git_diff(start, end)
    (total, add, delete) = parse_diff_log(diff)
    os.chdir(saved_dir)
    return (total, add, delete)

# get first/last commits from git log
def get_commits_from_shortstat(shortstat):
    commit_flag = 'commit '
    len_commit_flag = len(commit_flag)
    len_commit = 40  # git commit has 40 chars due to SHA-1 algorithm
    if shortstat.count(commit_flag) == 1:
        end = shortstat[len_commit_flag:len_commit_flag+len_commit]
        start = end + '^'
    elif shortstat.count(commit_flag) >= 2:
        first_index = shortstat.index(commit_flag)
        last_index = shortstat.rindex(commit_flag)
        end = shortstat[first_index+len_commit_flag:first_index+len_commit_flag+len_commit]
        start = shortstat[last_index+len_commit_flag:last_index+len_commit_flag+len_commit]
    else:
        start = '00000000000000000000'
        end = '00000000000000000000'
    return (start, end)

# exec 'git diff' command
'''
Know issue: when a file existed before but doesn't exist now, the delete of the file is not included. 
'''
def git_diff(start='00000000', end='00000000'):
    use_suffix = 1
    ext_cmd_str = ''
    if use_suffix == 1:
        ext_cmd_str = '--'
        for suffix in suffix_list:
            ext_cmd_str += ' **/*.%s' % suffix
        # need to set globstar in Bash before using ** to match any dir or files
        # 'globstar' is only for Bash
        git_diff_cmd = ['shopt -s globstar; git diff --shortstat %s %s %s' % (start, end, ext_cmd_str)]
    else:
        git_diff_cmd = ['git diff --shortstat %s %s' % (start, end)]
    print git_diff_cmd
    diff = exec_cmds.getpipeoutput(git_diff_cmd)
    print diff
    return diff

# parse log from 'git diff --shortstat commit1 commit2'
def parse_diff_log(diff):
    flag1 = 'changed, '
    flag2 = ' insertions(+), '
    flag3 = ' deletions'
    if diff.count('insertions')<1:
        add = 0
        delete = 0
    else:
        index1 = diff.index(flag1)
        index2 = diff.index(flag2)
        index3 = diff.index(flag3)
        add = diff[index1+len(flag1):index2]
        delete = diff[index2+len(flag2):index3]
    add = long(add)
    delete = long(delete)
    total = long(add) + long(delete)
    return (total, add, delete)

# calculate total lines of the repo
def cal_total_lines_using_git(mydir):
    if not os.path.exists(mydir):
        print("Error: %s doesn't exist." % mydir)
        return None
    saved_dir = os.getcwd()
    os.chdir(mydir)
    
    # short_stat_0 means the git log stat of the 1st commit of the repo
    short_stat_diff_0 = exec_cmds.getpipeoutput(['git log --shortstat --pretty=format:"" \
--no-merges |sed -n \'$p\''])
    (t0, a0, d0) = parse_diff_log(short_stat_diff_0)
    shortstat = exec_cmds.getpipeoutput(['git log --shortstat --pretty=short --no-merges'])
    (start, end) = get_commits_from_shortstat(shortstat)
    diff = exec_cmds.getpipeoutput(['git diff --shortstat %s %s' % (start, end)])
    (total, add, delete) = parse_diff_log(diff)
    add += a0
    delete += d0
    total = add - delete
#    print 'total=%d' % total
    
    os.chdir(saved_dir)
    return total

# find . -type f \( -name "*.java" -o -name "*.py" \) | xargs wc -l | sed -n '$p'
# calculate total line of the repo using 'find' and 'wc' tools
def cal_total_lines_using_find_wc(mydir):
    if not os.path.exists(mydir):
        print("Error: %s doesn't exist." % mydir)
        return None
    saved_dir = os.getcwd()
    os.chdir(mydir)
    
    name_str_list = []
    for suffix in suffix_list:
        name_str = '-name "*.%s"' % suffix
        name_str_list.append(name_str)
    str_pattern = ' -o '.join(name_str_list)
    cmd = "find . -type f \( %s \) | xargs wc -l | sed -n '$p' | awk '{print $1}'" % str_pattern
    total = exec_cmds.getpipeoutput([cmd], quiet=True)
    
    os.chdir(saved_dir)
#    print total
    return int(total)

# only for testing/debugging
if __name__ == '__main__':
    mydir = '/data/repo/info/info-search-web.git'
    month = '2013-09'
    print cal_by_month(mydir, month)
#    print cal_total_lines_using_git(mydir)
#    git_diff()
#    cal_total_lines_using_find_wc(mydir)
