'''
Created on Jan 17, 2014

@author: jay
'''

import sys
sys.path.append('..')
import db_connection
from config import gitlab_db_config

def get_repo_list_by_group(ns_path):
    repo_list = []
    cnx = db_connection.connect_db(**gitlab_db_config)
    if cnx == None:
        print "GitLab DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    sql = "SELECT p.id FROM projects AS p, namespaces AS n WHERE p.public=1 "\
        + "AND n.path='%s' AND p.namespace_id=n.id" % ns_path
    cursor.execute(sql)
    rows = cursor.fetchall()
    if rows:
        for row in rows:
            repo_list.append(row[0])
    cursor.close()
    db_connection.close_db(cnx)
    return repo_list

def get_app_by_repo(project_id):
    app_list = []
    cnx = db_connection.connect_db(**gitlab_db_config)
    if cnx == None:
        print "GitLab DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    sql = "SELECT module_name FROM project_modules WHERE project_id='%s'" % project_id
    cursor.execute(sql)
    rows = cursor.fetchall()
    if rows:
        for row in rows:
            app_list.append(row[0])
    cursor.close()
    db_connection.close_db(cnx)
    return app_list

if __name__ == '__main__':
#                   7:['adwords', 'midas', 'promo'],
#               8:['paycenter', 'tuangou',
    get_repo_list_by_group(ns_path='paycenter')
    get_app_by_repo(project_id='11')