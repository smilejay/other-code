#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Jan 17, 2014

@author: jay
'''

import urllib
import json

def get_ip_list(app = 'deal-service', env = 'beta', status = '在线'):
    url = 'http://cmdb.dp/cmdb/device/s?q=app:%s,env:%s,status=%s' % (app, env, status)
    doc = urllib.urlopen(url.encode('utf-8'))
    data = json.loads(doc.read())
    ip_list = [x['private_ip'] for x in data['result'] ]
    return ip_list

if __name__ == '__main__':
    print(get_ip_list(env='beta'))