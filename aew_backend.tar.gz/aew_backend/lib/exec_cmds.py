''' some functions when execute shell cmds

Copyright (C) 2013 Jay <yongjie.ren@dianping.com>
'''

import subprocess
import sys

def getpipeoutput(cmds, quiet = False):
        if not quiet:
                print '>> ' + ' | '.join(cmds),
                sys.stdout.flush()
        p0 = subprocess.Popen(cmds[0], stdout = subprocess.PIPE, shell = True)
        p = p0
        for x in cmds[1:]:
                p = subprocess.Popen(x, stdin = p0.stdout, stdout = subprocess.PIPE, shell = True)
                p0 = p
        output = p.communicate()[0]
        return output.rstrip('\n')


if __name__ == '__main__':
    output = getpipeoutput(['ls -l', 'wc -l'])
    print '\r\n' + output
