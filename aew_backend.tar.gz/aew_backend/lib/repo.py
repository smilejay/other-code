#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Dec 10, 2013

@author: Jay <yongjie.ren@dianping.com>
'''

import sys
sys.path.append('..')
import db_connection
from config import aew_db_config
import lib.gitlab as gitlab
import lib.cmdb as cmdb

def get_test_repos():
    '''
    @return: repo_list which is a dict of tuples.
             repo_list is like [('auto', 'aew_backend'), ('auto', 'bugzilla')].
             the 1st item in a tuple is the group and the 2nd one is the project path.
    '''
    repo_list = []
    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    sql = "SELECT ns_path, p_path FROM test_repo WHERE is_enable='Y'"
    cursor.execute(sql)
    rows = cursor.fetchall()
    if rows:
        for row in rows:
            repo_list.append((row[0], row[1]))
#     print repo_list
    cursor.close()
    db_connection.close_db(cnx)
    return repo_list

def get_ip_list_by_group(group, env, status = '在线'):
    ip_list = []
    app_list = [gitlab.get_app_by_repo(i) for i in gitlab.get_repo_list_by_group(ns_path=group)]
    for i in app_list:
        for j in i:
            ips = cmdb.get_ip_list(j, env, status)
            for x in ips:
                for y in x:
                    ip_list.append(y)
    return ip_list
        

if __name__ == '__main__':
#    get_test_repos()
    print get_ip_list_by_group(group='paycenter', env='生产')