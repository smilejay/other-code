#!/usr/bin/python
''' DB connection functions (current only for MySQL)

Copyright (C) 2013  Jay <yongjie.ren@dianping.com>
'''

import mysql.connector
from mysql.connector import errorcode

# connect MySQL DB using config
def connect_db(**db_config):
    try:
        cnx = mysql.connector.connect(**db_config)
    except mysql.connector.Error as err:
        cnx = None
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            print "Something is wrong with your user name or password"
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            print "Database does not exists"
        else:
            print err
    finally:
        return cnx

# close MySQL DB connnection
def close_db(cnx):
    cnx.close()

# commit this transaction
def commit(cnx):
    cnx.commit()
