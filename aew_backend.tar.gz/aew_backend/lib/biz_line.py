'''
Created on Dec 4, 2013

@author: Jay <yongjie.ren@dianping.com>
'''
import sys
sys.path.append('..')
import lib.db_connection as db_connection
from config import aew_db_config

def get_biz_id_list():
    '''
    get the list of biz line IDs in biz table.
    '''
    biz_id_list = []
    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    sql = 'SELECT id FROM biz WHERE id != 12'
    cursor.execute(sql)
    rows = cursor.fetchall()
    if rows:
        for row in rows:
            biz_id_list.append(row[0])
#    print biz_id_list
    cursor.close()
    db_connection.close_db(cnx)
    return biz_id_list

def get_name_by_id(biz_id):
    '''
    get biz name by biz ID
    '''
    name = 'Undefined'
    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    sql = "SELECT name FROM biz WHERE id='" + str(biz_id) + "';"
    cursor.execute(sql)
    row = cursor.fetchone()
    if row:
        name = row[0]
    cursor.close()
    db_connection.close_db(cnx)
#    print name
    return name

if __name__ == '__main__':
    get_biz_id_list()
    get_name_by_id(1)