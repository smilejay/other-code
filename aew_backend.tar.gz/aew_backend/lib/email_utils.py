#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Oct 23, 2013

@summary: the email utility for sending emails
@author: Jay <yongjie.ren@dianping.com>
'''

import smtplib

#SMTP server
server_ip = '10.1.77.82'

def send_email(from_addr='任永杰<yongjie.ren@dianping.com>', to_addrs=['yongjie.ren@dianping.com'], \
               subject='AEW warning', body='test from aew'):
    """ send email for caller.
    @from_addr: the address of the sender
    @to_addrs: a address list for the receivers
    @subject: email subject
    @body: email message body
    """
    # we need to set a header as some mailing service provider prevent spams
    # now, we use HTML body.
    headers = ["From: " + from_addr,
           "Subject: " + subject,
           "To: " + ', '.join(to_addrs),
           "MIME-Version: 1.0",
           "Content-Type: text/html"]
    headers = "\r\n".join(headers)
    msg = headers + "\r\n\r\n" + body.encode('utf-8')
#     print msg
    server = smtplib.SMTP(server_ip)
#     server.set_debuglevel(1)  # to print more debug info
    server.sendmail(from_addr, to_addrs, msg)
    server.quit()

if __name__ == '__main__':
    body = 'This is a test e-mail message.'
    send_email(body=body)