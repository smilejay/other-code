#!/usr/bin/python
# -*- encoding:utf-8 -*-

'''
Created on Sep 25, 2013

The library to deal with time, date, month, year, and so on.

@author: Jay <yongjie.ren@dianping.com>
'''

from datetime import datetime, timedelta
from calendar import mdays

def list_months(start, end):
    month_list = []
    start = datetime.strptime(start, '%Y-%m')
    end = datetime.strptime(end, '%Y-%m')
    if start > end:
        print "warning! start_date > end_date"
        month_list.append(start.strftime('%Y-%m'))
    while (start <= end):
        month_list.append(start.strftime('%Y-%m'))
        start += timedelta(days=mdays[start.month])
#     print month_list
    return month_list

def get_month_before_last_month(month):
    month = datetime.strptime(month, '%Y-%m')
    month_before_last_month = month - timedelta(days=40)
    return datetime.strftime(month_before_last_month, '%Y-%m')

if __name__ == '__main__':
    print get_month_before_last_month('2013-10')
#    list_months('2013-01', '2013-09')
#    list_months('2013-10', '2013-09')
#    list_months('2013-02', '2014-05')