#!/bin/bash
#set -x
# check each repo's branch; if it's not master, log it in a file.
# Copyright (C) 2013 Jay <yongjie.ren@dianping.com>

base_dir=/data/repo
logfile=/home/repo/branch_not_master.log
echo > $logfile
cd $base_dir
for i in $(ls)
do
	cd $i
	for j in $(ls)
	do
		cd $j
		git branch | grep "master" | grep "*" &>/dev/null
		if [ $? -ne 0 ]; then
			echo "$i $j $(git branch)" >> $logfile
		fi
		git branch -r | grep "HEAD" | grep "master" &> /dev/null
		if [ $? -ne 0 ]; then
			echo "$i $j $(git branch -r | grep 'HEAD')" >> $logfile
		fi
		cd ..
	done
	cd ..
done
