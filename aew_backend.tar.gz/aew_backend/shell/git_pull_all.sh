#!/bin/bash
#set -x
# git pull all the repos, if failed, log it into a file or email to the admin
# Copyright (C) 2013 Jay <yongjie.ren@dianping.com>

base_dir=/data/repo
logfile=/home/repo/git_pull_failed.log
echo > $logfile
cd $base_dir
for i in $(ls)
do
        cd $i
        for j in $(ls)
        do
                cd $j
                git pull &>/dev/null
                if [ $? -ne 0 ]; then
                        echo "$i $j git-pull failed" >> $logfile
			cd ..
			rm -rf $j
                else
			cd ..
		fi
        done
        cd ..
done

