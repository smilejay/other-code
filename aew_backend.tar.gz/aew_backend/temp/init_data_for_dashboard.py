'''
Created on Apr 2, 2014

@author: Jay <yongjie.ren@dianping.com>
'''

import random
import sys
sys.path.append("..")
import lib.db_connection as db_connection
from config import aew_db_config

def init_second_total(cursor):
    del_sql = "DELET FROM second_total WHERE id BETWEEN 0 AND 60"
    cursor.execute(del_sql)
    db_connection.commit(cnx)
    total = 0
    for i in range(60):
        total += random.randrange(1000,2000)
        sql = "INSERT INTO second_total(id, pv, uv) VALUES(%d, %d, %d)" % (i, total, total)
        cursor.execute(sql)
        db_connection.commit(cnx)
        
def init_minute_total(cursor):
    del_sql = "DELET FROM minute_total WHERE id BETWEEN 0 AND 60"
    cursor.execute(del_sql)
    db_connection.commit(cnx)
    total = 0
    for i in range(60):
        total += random.randrange(65000, 75000)
        sql = "INSERT INTO minute_total(id, pv, uv) VALUES(%d, %d, %d)" % (i, total, total)
        cursor.execute(sql)
        db_connection.commit(cnx)

def init_hour_total(cursor):
    del_sql = "DELET FROM hour_total WHERE id BETWEEN 0 AND 24"
    cursor.execute(del_sql)
    db_connection.commit(cnx)
    total = 0
    for i in range(24):
        total += random.randrange(4150000, 4180000)
        sql = "INSERT INTO hour_total(id, pv, uv) VALUES(%d, %d, %d)" % (i, total, total)
        cursor.execute(sql)
        db_connection.commit(cnx)

if __name__ == '__main__':
    cnx = db_connection.connect_db(**aew_db_config)
    if cnx == None:
        print "AEW DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    init_second_total(cursor)
    init_minute_total(cursor)
    init_hour_total(cursor)
    cursor.close()
    db_connection.close_db(cnx)