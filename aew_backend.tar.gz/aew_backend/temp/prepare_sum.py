#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
Created on Apr 7, 2014

@author: jay
'''

import xml.dom.minidom

fileStr = 'sum.xml'

def gen_sum(data):
    '''
    generate a XML file for the sum of PV data. 
    '''  
    impl = xml.dom.minidom.getDOMImplementation()  
    dom = impl.createDocument(None, 'SUM', None)  
    root = dom.documentElement
    
    for i in data:
        ele = dom.createElement(i)
        ele_text = dom.createTextNode(data[i])  
        ele.appendChild(ele_text)    
        root.appendChild(ele)
          
    f = open(fileStr, 'w')  
    dom.writexml(f, addindent='  ', newl='\n')  
    f.close()

data = {'pv_dt':'2014-04-07', 'pv':'100000'}
gen_sum(data)  