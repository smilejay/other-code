#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Jan 17, 2014

@author: jay
'''

import sys
sys.path.append('..')
import lib.repo as repo

ns_list = ['ba-crm', 'ba-mobile', 'ba-pc']

if __name__ == '__main__':
    ip_list = []
    for ns in ns_list:
        ip_list += repo.get_ip_list_by_group(group=ns, env='beta', status='在线')
    for i in ip_list:
        print i
    print('There\'re %d IP addrs.' % len(ip_list))
#    print(i for i in ip_list)