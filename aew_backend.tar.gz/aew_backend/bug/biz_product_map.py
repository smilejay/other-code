#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Sep 25, 2013

@author: Jay <yongjie.ren@dianping.com>
'''
import sys
sys.path.append("..")
import lib.db_connection as db_connection
from config import bugzilla_db_config

def get_biz_product_mapping():
    '''
    map biz line and bugzilla product.
    '''
    biz_product_dict = {'1':[], '2':[], '3':[], '4':[], '5':[], '6':[], '7':[], '8':[], '9':[], '10':[], '11':[]}
    
    cnx = db_connection.connect_db(**bugzilla_db_config)
    if cnx == None:
        print "DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    
    sql1 = "SELECT id FROM products WHERE classification_id=(SELECT id FROM classifications WHERE name='信息线')" + \
           " AND name NOT IN ('结婚', '酒店预订项目')"
    sql2 = "SELECT id FROM products WHERE name='结婚'"
    sql3 = "SELECT id FROM products WHERE name='酒店预订项目'"
    sql4 = "SELECT id FROM products WHERE classification_id IN (SELECT id FROM classifications WHERE name='开放平台')"
    sql5 = "SELECT id FROM products WHERE name='预约预订'"
    sql6 = "SELECT id FROM products WHERE name='外卖'"
    sql7 = "SELECT id FROM products WHERE name='广告中心'"
    sql8 = "SELECT id FROM products WHERE classification_id=(SELECT id FROM classifications WHERE name='交易平台')" + \
            " AND name NOT IN ('cat相关异常')"
    sql9 = "SELECT id FROM products WHERE classification_id IN (SELECT id FROM classifications WHERE name='通用服务')"
    sql10 = "SELECT id FROM products WHERE classification_id=(SELECT id FROM classifications WHERE name='业务系统')"
    sql11 = "SELECT id FROM products WHERE classification_id=(SELECT id FROM classifications WHERE name='平台技术及第三方')"
    
    sql_list = [sql1, sql2, sql3, sql4, sql5, sql6, sql7, sql8, sql9, sql10, sql11]
    for sql in sql_list:
#        print sql
        cursor.execute(sql)
        row_list = cursor.fetchall()
        pro_list = []
        for row in row_list:
            pro_list.append(row[0])
        biz_product_dict[str(sql_list.index(sql)+1)] = pro_list
    
    cursor.close()
    db_connection.close_db(cnx)
    
#    print biz_product_dict
    return biz_product_dict

if __name__ == '__main__':
    get_biz_product_mapping()
