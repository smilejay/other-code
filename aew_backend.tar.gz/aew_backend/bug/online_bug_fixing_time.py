#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Sep 30, 2013

calculate the fixing time of the online bugs.

@author: jay
'''

import sys
sys.path.append("..")
import lib.db_connection as db_connection
import lib.date_utils as date_utils
from config import bugzilla_db_config
from datetime import datetime,timedelta
from calendar import mdays
import getopt


def get_online_bug_fixing_time(month):
    start_datetime = datetime.strptime(month, "%Y-%m")
    end_datetime = start_datetime + timedelta(days=mdays[start_datetime.month])
    start_date = start_datetime.date().isoformat()
    end_date = end_datetime.date().isoformat()
    
    cnx = db_connection.connect_db(**bugzilla_db_config)
    if cnx == None:
        print "DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    
    # so far, only support P1~P4 bugs
    pri_str_list = ['P1-Critical', 'P2-Important'] # only for P1/P2, you can add 'P3-Normal', 'P4-Minor']
    bug_nr_list = []
    avg_hr_list = []
    for pri_str in pri_str_list:
        sql1 = "SELECT count(*) FROM bugs WHERE cf_bug_env='线上环境' AND resolution NOT IN ('INVALID', 'NOT-OUR-CAUSE') AND "\
               + "priority='%s' AND creation_ts BETWEEN '%s' AND '%s'" % (pri_str, start_date, end_date) 
        cursor.execute(sql1)
        nr = cursor.fetchone()
        bug_nr_list.append(nr[0])
        
        sql2 = "SELECT TIME_TO_SEC(TIMEDIFF(cf_prodbug_closetime, cf_prodbug_starttime)) FROM bugs WHERE  cf_bug_env = '线上环境' " + \
                "AND priority='" + pri_str + "' AND creation_ts BETWEEN '" + start_date + "' AND '" + end_date + "' " + \
                "AND cf_prodbug_closetime IS NOT NULL AND cf_prodbug_starttime is NOT NULL;"
        cursor.execute(sql2)
        rows = cursor.fetchall()
        counter = 0
        sum_time = 0
        for row in rows:
            if row[0] > 0:
                sum_time += row[0]
                counter += 1
        if counter > 0:
            avg = sum_time/counter   # in seconds
            avg_hr = float(avg)/3600   # in hours
            avg_hr = '%.2f' % avg_hr
        else:
            avg_hr = 0  # if no data about the fixing time in DB
        avg_hr_list.append(avg_hr)
    
    cursor.close()
    db_connection.close_db(cnx)
    return [bug_nr_list, avg_hr_list, pri_str_list]

def show_multimonth_fixing_time():
    month_list = date_utils.list_months('2013-01', '2013-11')
    for month in month_list:
        print '---------------------------------------------------------------'
        print "month=" + month
        lists = get_online_bug_fixing_time(month)
        for i,j,p in zip(lists[0], lists[1], lists[2]):
            print str(p) + " bug_nr=" + str(i) + "  average_fixing_time=" + str(j) + "hrs"

def show_fixing_time(month):
    start = date_utils.get_month_before_last_month(month)
    end = month
    month_list = date_utils.list_months(start, end)
    for month in month_list:
        print '---------------------------------------------------------------'
        print "month=" + month
        lists = get_online_bug_fixing_time(month)
        for i,j,p in zip(lists[0], lists[1], lists[2]):
            print str(p) + " bug_nr=" + str(i) + "  average_fixing_time=" + str(j) + "hrs"

# FIXME
def show_yearly_fixing_time(year='2013'):
    print 'list yearly online bugs'    

# FIXME
def usage():
    print 'print usage'

# main function
def main():
    month =''
    year = ''
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'hm:y:', ['help', 'month=', 'year='])
    except getopt.GetoptError as err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    for opt, arg in opts:
        if opt in ('-h', '--help'):
            usage()
            sys.exit(0)
        elif opt in ('-m', '--month'):
            month = arg
        elif opt in ('-y', '--year'):
            year = arg
        else:
            assert False, "unhandled option"
    
    if month:
        show_fixing_time(month)
    elif year:
        show_yearly_fixing_time(year)
    else:
        show_yearly_fixing_time()   

if __name__ == '__main__':
    main()
