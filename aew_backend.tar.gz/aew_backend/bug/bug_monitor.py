#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Nov 11, 2013

@author: Jay <yongjie.ren@dianping.com>
'''

import sys
sys.path.append("..")
import lib.db_connection as db_connection
from datetime import datetime
from config import bugzilla_db_config
from lib.email_utils import send_email

msg0 = '%s    table:%s    ID:%s    name:%s'
# set from_addr, to_addrs, subject, body of the warning email
from_addr = '任永杰 <yongjie.ren@dianping.com>'
to_addrs = ['任永杰 <yongjie.ren@dianping.com>']
subject = 'Bugzilla warning from AEW system'
body = ''  # you should use HTML body.

today = datetime.today()
first_day_of_this_moth = datetime(today.year, today.month, 1)

def show_bugzilla_classification_changes(start=first_day_of_this_moth, end=today):
    '''
    When there's any log record in bugzilla_log table in bugzilla DB, it will send email to the administrator.
    '''
    cnx = db_connection.connect_db(**bugzilla_db_config)
    if cnx == None:
        print "DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    
    msg_list = []
    sql1 = "SELECT log.id, log.table, log.action FROM bugzilla_log AS log WHERE ts BETWEEN '%s' AND '%s'" % (start, end)
    cursor.execute(sql1)
    rows = cursor.fetchall()
    for row in rows:
        if row[2] != 'delete':
            sql2 = 'SELECT name FROM %s WHERE id=%d' % (row[1], int(row[0]))
            cursor.execute(sql2)
            col = cursor.fetchone()
            if col != None:
                msg = msg0 % (row[2], row[1], row[0], col[0])
                msg_list.append(msg)
        else:
            msg = msg0 % (row[2], row[1], row[0], '')
            msg_list.append(msg)
    
    if len(msg_list) != 0:
        time_val = '%s ~ %s <br />' % (start, end)
        body = time_val + '<br />'.join(msg_list)
#        print body
        send_email(from_addr, to_addrs, subject, body)
    
    cursor.close()
    db_connection.close_db(cnx)
    
if __name__ == '__main__':
#    show_bugzilla_classification_changes(start='2013-11-8')
    show_bugzilla_classification_changes()