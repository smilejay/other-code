#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Sep 29, 2013

@author: Jay <yongjie.ren@dianping.com>
'''

import sys
sys.path.append("..")
import lib.db_connection as db_connection
import lib.date_utils as date_utils
import lib.biz_line as biz_line
from config import bugzilla_db_config, aew_db_config
from datetime import datetime,timedelta
from calendar import mdays
import biz_product_map
import getopt

# the list of biz line IDs
biz_ids = biz_line.get_biz_id_list()

def monthly_offline_bugs_by_product(product_id, month):
    start_datetime = datetime.strptime(month, "%Y-%m")
    end_datetime = start_datetime + timedelta(days=mdays[start_datetime.month])
    start_date = start_datetime.date().isoformat()
    end_date = end_datetime.date().isoformat()
    
    cnx = db_connection.connect_db(**bugzilla_db_config)
    if cnx == None:
        print "Bugzilla DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()
    
    pri_str_list = ['P1-Critical', 'P2-Important', 'P3-Normal', 'P4-Minor']
    bug_nr_list = []
    for pri_str in pri_str_list:
        sql = "SELECT count(*) FROM bugs WHERE cf_bug_env NOT IN ('线上环境','ONLINECAT') AND bugs.resolution!='INVALID' "\
               + "AND priority='%s' AND creation_ts BETWEEN '%s' AND '%s' AND product_id='%s'" \
                % (pri_str, start_date, end_date, str(product_id))
#        print sql
        cursor.execute(sql)
        nr = cursor.fetchone()
        bug_nr_list.append(nr[0])
    
    cursor.close()
    db_connection.close_db(cnx)
    bug_nr_12_34=[bug_nr_list[0]+bug_nr_list[1], bug_nr_list[2]+bug_nr_list[3]]
#     print [bug_nr_list, bug_nr_12_34]
    return [bug_nr_list, bug_nr_12_34]

def monthly_sum_offline_bugs_in_product_list(product_list, month_list):
    for month in month_list:
        nr_p1 = nr_p2 = nr_p3 = nr_p4 = 0
#        print "month=" + month
        for product_id in product_list:
            nr_bugs = monthly_offline_bugs_by_product(product_id, month)
            nr_p1 += nr_bugs[0][0]
            nr_p2 += nr_bugs[0][1]
            nr_p3 += nr_bugs[0][2]
            nr_p4 += nr_bugs[0][3]
        print month + " 线下bug总数：" + str(nr_p1 + nr_p2 + nr_p3 + nr_p4)
#        print "P1 bugs:" + str(nr_p1)
#        print "P2 bugs:" + str(nr_p2)
#        print "P3 bugs:" + str(nr_p3)
#        print "P4 bugs:" + str(nr_p4)   

def list_monthly_offline_bugs(month='2013-11'):
    '''
    show the data of the recent 3 months
    e.g. when month='2013-11', the data is about 2013-09, 2013-10 and 2013-11.
    '''
    print "%s 线下bug情况如下：" % month
    start = date_utils.get_month_before_last_month(month)
    end = month
    month_list = date_utils.list_months(start, end)
    biz_product_dict = biz_product_map.get_biz_product_mapping()
    for key in biz_ids:
        print "--------------------------------------------"
        cnx = db_connection.connect_db(**aew_db_config)
        if cnx == None:
            print "Bugzilla DB connection ERROR!!"
            sys.exit(1)
        cursor = cnx.cursor()
        sql = "SELECT name FROM biz WHERE id='" + str(key) +"';"
        cursor.execute(sql)
        row = cursor.fetchone()
        print row[0]
        monthly_sum_offline_bugs_in_product_list(biz_product_dict[str(key)], month_list)

# FIXME
def list_yearly_offline_bugs(year='2013'):
    print 'get yearly offline bugs'

# FIXME
def usage():
    print 'print usage'

# main function
def main():
    month =''
    year = ''
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'hm:y:', ['help', 'month=', 'year='])
    except getopt.GetoptError as err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    for opt, arg in opts:
        if opt in ('-h', '--help'):
            usage()
            sys.exit(0)
        elif opt in ('-m', '--month'):
            month = arg
        elif opt in ('-y', '--year'):
            year = arg
        else:
            assert False, "unhandled option"
    
    if month:
        list_monthly_offline_bugs(month)
    elif year:
        list_yearly_offline_bugs(year)
    else:
        list_yearly_offline_bugs()
    
if __name__ == '__main__':
    main()
#     monthly_online_bugs_by_product(129, '2013-04')
#    list_monthly_offline_bugs()
