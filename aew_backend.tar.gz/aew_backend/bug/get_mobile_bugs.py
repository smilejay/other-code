#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Oct 11, 2013

@author: Jay <yongjie.ren@dianping.com>
'''

import sys
sys.path.append("..")
import lib.db_connection as db_connection
import lib.date_utils as date_utils
from config import bugzilla_db_config
from datetime import datetime,timedelta
from calendar import mdays
import getopt

def get_mobile_comp_id_list():
    ''' get component_id list of each business line
        @return: mobile_comp_id_list
        1. biz order of the list: 'info', 'tuangou', 'mcard', 'rs', 'ba'
        2. M-site and WAP-site are not included.
        3. API is included.
    '''
    sql_list = []
    # sql for info line
    sql_list.append("SELECT id FROM components WHERE product_id IN " + \
                "( SELECT id FROM products WHERE name IN " + \
                "('Mobile_Android', 'Mobile_iPad', 'Mobile_iPhone', 'Mobile_WP', 'Mobile_服务端', 'Mobile_线上问题') " + \
                "AND classification_id=(SELECT id FROM classifications WHERE name='信息线') );")
    # sql for tuangou
    sql_list.append("SELECT id FROM components WHERE name NOT IN ('团购M站点', '团购WAP') " + \
                "AND product_id IN (SELECT id FROM products WHERE name IN ('手机团购', '团购商家POS机APP'));")
    # sql for mcard
    sql_list.append("SELECT id FROM components WHERE name IN ('android客户端', 'iphone客户端', 'POS机', 'API') " + \
                "AND product_id IN (SELECT id FROM products WHERE name='商户会员卡');")
    # sql for rs
    sql_list.append("SELECT id FROM components WHERE name IN ('Android客户端', 'IPhone客户端', 'IPad客户端', 'API') " + \
                "AND product_id IN (SELECT id FROM products WHERE name='预约预订');")
    # sql for BA
    sql_list.append("SELECT id FROM components WHERE name IN ('APP', '商户中心app - iOS', '商户中心app - 安卓') " + \
                "AND product_id IN (SELECT id FROM products WHERE classification_id=(SELECT id FROM classifications WHERE name='业务系统'));")

    cnx = db_connection.connect_db(**bugzilla_db_config)
    if cnx == None:
        print "Bugzilla DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()

    biz_comp_id_list = []
    for sql in sql_list:
        comp_id_list = []
        cursor.execute(sql)
        rows = cursor.fetchall()
        for row in rows:
            comp_id_list.append(row[0])
#        print comp_id_list
        biz_comp_id_list.append(comp_id_list)

    cursor.close()
    db_connection.close_db(cnx)
    return biz_comp_id_list

def monthly_offline_bugs_by_component(component_id, month):
    start_datetime = datetime.strptime(month, "%Y-%m")
    end_datetime = start_datetime + timedelta(days=mdays[start_datetime.month])
    start_date = start_datetime.date().isoformat()
    end_date = end_datetime.date().isoformat()

    cnx = db_connection.connect_db(**bugzilla_db_config)
    if cnx == None:
        print "Bugzilla DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()

    pri_str_list = ['P1-Critical', 'P2-Important', 'P3-Normal', 'P4-Minor']
    bug_nr_list = []
    for pri_str in pri_str_list:
        sql = "SELECT count(*) FROM bugs WHERE cf_bug_env NOT IN ('线上环境','ONLINECAT') AND resolution NOT IN ('INVALID', 'NOT-OUR-CAUSE') AND "\
              +  "priority='%s' AND creation_ts BETWEEN '%s' AND '%s' AND component_id=%d" % (pri_str, start_date, end_date, component_id)
#        print sql
        cursor.execute(sql)
        nr = cursor.fetchone()
        bug_nr_list.append(nr[0])

    cursor.close()
    db_connection.close_db(cnx)
    bug_total_nr = bug_nr_list[0]+bug_nr_list[1]+bug_nr_list[2]+bug_nr_list[3]
    return [bug_nr_list, bug_total_nr]

def monthly_sum_offline_bugs_in_comp_list(comp_list, month_list):
    nr_list = []
    for month in month_list:
        total_nr = nr_p1 = nr_p2 = nr_p3 = nr_p4 = 0
#        print "month=" + month
        for component_id in comp_list:
            nr_bugs = monthly_offline_bugs_by_component(component_id, month)
            nr_p1 += nr_bugs[0][0]
            nr_p2 += nr_bugs[0][1]
            nr_p3 += nr_bugs[0][2]
            nr_p4 += nr_bugs[0][3]
            total_nr += nr_bugs[1]
        nr_list.append(total_nr)
        print "%s 线下bug总数：%d" % (month, total_nr)
#    print nr_list

def show_monthly_offline_bugs(month='2013-11'):
    '''
    show the data of the recent 3 months
    e.g. when month='2013-11', the data is about 2013-09, 2013-10 and 2013-11.
    '''
    start = date_utils.get_month_before_last_month(month)
    end = month
    month_list = date_utils.list_months(start, end)
    print '移动 线下bug统计'
    biz_comp_list = get_mobile_comp_id_list()
    for comp_list in biz_comp_list:
        if comp_list == biz_comp_list[0]:
            biz_str = '主站'
        elif comp_list == biz_comp_list[1]:
            biz_str = '团购'
        elif comp_list == biz_comp_list[2]:
            biz_str = '会员卡'
        elif comp_list == biz_comp_list[3]:
            biz_str = '预约预订'
        elif comp_list == biz_comp_list[4]:
            biz_str = '业务系统'
        else:
            biz_str = '移动产品不存在'
        print '------------------------------------------------------'
        print '%s 移动:' % biz_str
        monthly_sum_offline_bugs_in_comp_list(comp_list, month_list)
    print '------------------------------------------------------'

def monthly_online_bugs_by_component(component_id, month):
    start_datetime = datetime.strptime(month, "%Y-%m")
    end_datetime = start_datetime + timedelta(days=mdays[start_datetime.month])
    start_date = start_datetime.date().isoformat()
    end_date = end_datetime.date().isoformat()

    cnx = db_connection.connect_db(**bugzilla_db_config)
    if cnx == None:
        print "Bugzilla DB connection ERROR!!"
        sys.exit(1)
    cursor = cnx.cursor()

    pri_str_list = ['P1-Critical', 'P2-Important', 'P3-Normal', 'P4-Minor']
    bug_nr_list = []
    for pri_str in pri_str_list:
        sql = "SELECT count(*) FROM bugs WHERE cf_bug_env='线上环境' AND priority='%s' " % pri_str \
            + "AND creation_ts BETWEEN '%s' AND '%s' AND component_id=%d" % (start_date, end_date, component_id)
#        print sql
        cursor.execute(sql)
        nr = cursor.fetchone()
        bug_nr_list.append(nr[0])

    cursor.close()
    db_connection.close_db(cnx)
    bug_total_nr = bug_nr_list[0]+bug_nr_list[1]+bug_nr_list[2]+bug_nr_list[3]
    return [bug_nr_list, bug_total_nr]

def monthly_sum_online_bugs_in_comp_list(comp_list, month_list):
    nr_list = []
    for month in month_list:
        total_nr = nr_p1 = nr_p2 = nr_p3 = nr_p4 = 0
#        print "month=" + month
        for component_id in comp_list:
            nr_bugs = monthly_online_bugs_by_component(component_id, month)
            nr_p1 += nr_bugs[0][0]
            nr_p2 += nr_bugs[0][1]
            nr_p3 += nr_bugs[0][2]
            nr_p4 += nr_bugs[0][3]
            total_nr += nr_bugs[1]
        nr_list.append(total_nr)
        print "%s 线上bug总数：%d" % (month, total_nr)
#    print nr_list

def show_monthly_online_bugs(month='2013-11'):
    '''
    show the data of the recent 3 months
    e.g. when month='2013-11', the data is about 2013-09, 2013-10 and 2013-11.
    '''
    start = date_utils.get_month_before_last_month(month)
    end = month
    month_list = date_utils.list_months(start, end)
    print '移动 线上bug统计'
    biz_comp_list = get_mobile_comp_id_list()
    for comp_list in biz_comp_list:
        if comp_list == biz_comp_list[0]:
            biz_str = '主站'
        elif comp_list == biz_comp_list[1]:
            biz_str = '团购'
        elif comp_list == biz_comp_list[2]:
            biz_str = '会员卡'
        elif comp_list == biz_comp_list[3]:
            biz_str = '预约预订'
        elif comp_list == biz_comp_list[4]:
            biz_str = '业务系统'
        else:
            biz_str = '移动产品不存在'
        print '------------------------------------------------------'
        print '%s 移动:' % biz_str
        monthly_sum_online_bugs_in_comp_list(comp_list, month_list)
    print '------------------------------------------------------'

# FIXME
def show_yearly_offline_bugs(year='2013'):
    print 'list yearly offline bugs'

# FIXME
def show_yearly_online_bugs(year='2013'):
    print 'list yearly online bugs'

# FIXME
def usage():
    print 'print usage'

# main function
def main():
    month =''
    year = ''
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'hm:y:', ['help', 'month=', 'year='])
    except getopt.GetoptError as err:
        # print help information and exit:
        print str(err) # will print something like "option -a not recognized"
        usage()
        sys.exit(2)
    for opt, arg in opts:
        if opt in ('-h', '--help'):
            usage()
            sys.exit(0)
        elif opt in ('-m', '--month'):
            month = arg
        elif opt in ('-y', '--year'):
            year = arg
        else:
            assert False, "unhandled option"

    if month:
        show_monthly_offline_bugs(month)
        show_monthly_online_bugs(month)
    elif year:
        show_yearly_offline_bugs(year)
        show_yearly_online_bugs(year)
    else:
        show_yearly_offline_bugs(year)
        show_yearly_online_bugs(year)

if __name__ == '__main__':
    main()
#    get_mobile_comp_id_list()
#    show_monthly_offline_bugs()
#    show_monthly_online_bugs()
