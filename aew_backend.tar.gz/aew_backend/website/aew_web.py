#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Nov 26, 2013

@summary: This module provides some APIs and web pages to fetch some data from our AEW system.
        1. lines_number of a project (or a group)
        2. biz lines and their corresponding repo groups
        3. code changes (by line) of a group or a project
        4. branches of a catalog  (CMDB)
        5. ip list of an environment (CMDB)

@author: Jay <yongjie.ren@dianping.com>
'''

import web
import json
import sys
import cmdb
import repo
from datetime import datetime
sys.path.append("..")
from config import aew_db_config as conf

reload(sys)
sys.setdefaultencoding('utf-8')

render = web.template.render('templates/')
aew_db = web.database(dbn='mysql', host=conf['host'], user=conf['user'], pw=conf['password'], db=conf['database'])

urls = (
  '/', 'index',
  '/repo/lines', 'lines',
  '/repo/changes', 'changes',
  '/api/repo/lines', 'lines_api',
  '/cmdb/catalog_branch', 'catalog_branch',
  '/cmdb/ip_list_per_env', 'ip_list_per_env',
  '/api/cmdb/ip', 'ip_api'
)

class index():
    def GET(self):
        return render.index()

class lines():
    '''
    to handle the web visit to query the nr_lines of a group/project.
    '''
    def GET(self):
        i = web.input()
        myinput = {}
        if i.has_key('group') and i.group:
            myinput['group'] = i.group
        if i.has_key('project') and i.project:
            myinput['project'] =i.project
        lines_api_inst = lines_api()
        ret = lines_api_inst.GET(myinput)
        ret = json.loads(ret)
        if ret.has_key('err_msg') and ret['err_msg']:
            return "Error!\nerr_msg: %s" % ret['err_msg'] 
        else:
            # if no 'err_msg', i.group should not be null.
#            print i.group
#            print ret
            return render.lines(i.group, ret)

class changes():
    '''
    web page to show the code line changes of a group/project.
    '''
    def GET(self):
        i = web.input()
        project = None
        month = None
        if i.has_key('group') and i.group:
            group = i.group
        else:
            return 'Error!\n param \'group\' is needed and should NOT be a null string.'
        if i.has_key('project') and i.project:
            project =i.project
        elif not i.has_key('month') or not i.month:
            return 'Error!\n if no param \'project\' provided, param \'month\' is needed.'
        if i.has_key('month') and i.month:
            month = i.month
            month = datetime.strptime(month, "%Y-%m").date().strftime("%Y-%m-%d")
        if not project:
            ret = repo.changes_by_group(group, month)
        else:
            ret = repo.changes_by_repo(group, project, month)
        return render.changes(ret)

class lines_api():
    '''
    REST API: to query nr_lines of a group/project.
    '''
    def GET(self, myinput=None):
        ret = {}
        group_data = {}
        project_data = {}
        detail_data = {}
        if myinput:
            i = myinput
        else:
            i = web.input()
        if not i.has_key('group'):
            ret['err_msg'] = 'parameter \'group\' is needed.'
            return json.dumps(ret)
        elif not i['group']:
            ret['err_msg'] = 'value of parameter \'group\' should NOT be a null string.'
            return json.dumps(ret)
        group = i['group']
        if i.has_key('project') and i['project']:
            '''
            project available; get the info for the project. 
            '''
            project = i['project']
            db_data_p = aew_db.select('total_lines_repo', \
                                                what='total_lines as nr_lines, modify_time', \
                                                where="ns_path=$group AND p_path=$project", vars=locals())
            if db_data_p:
                db_data_p = db_data_p[0]
                project_data['nr_lines'] = str(db_data_p.nr_lines)
                project_data['modify_time'] = str(db_data_p.modify_time)
                ret['%s/%s' % (group, project)] = project_data
            else:
                ret['err_msg'] = 'Can\'t find lines info of the project %s/%s.' % (group, project)
            return json.dumps(ret, sort_keys = True, indent = 4, separators=(',', ': '))
        else:
            '''
            no project; get the info for the group.
            '''
#            sql1 = "SELECT SUM(total_lines) as nr_lines FROM total_lines_repo WHERE ns_path='%s'" % group
#            total_lines_by_group = aew_db.query(sql1)[0].nr_lines
            db_data = aew_db.select('total_lines_repo', \
                                    what='SUM(total_lines) as nr_lines, MAX(modify_time) as modify_time', \
                                    where="ns_path=$group", vars=locals())[0]
            if (not db_data) or (not db_data.nr_lines):
                ret['err_msg'] = 'Can\'t find lines info of the group: %s.' % group
            else:
                group_data['nr_lines'] = str(db_data.nr_lines)
                group_data['modify_time'] = str(db_data.modify_time)
                ret[group] = group_data
                db_data_p = aew_db.select('total_lines_repo', \
                                        what='p_path, total_lines as nr_lines, modify_time', \
                                        where="ns_path=$group", vars=locals())
                for j in db_data_p:
                    project_data = {}
                    project_data['nr_lines'] = str(j.nr_lines)
                    project_data['modify_time'] = str(j.modify_time)
                    detail_data['%s/%s' % (group, j.p_path)] = project_data
                ret['details'] = detail_data
            return json.dumps(ret, sort_keys = True, indent = 4, separators=(',', ': '))
        
class catalog_branch:
    '''
    to list catalog_branch of a catalog (from CMDB system).
    '''
    def GET(self):
        env = 'beta'
        i = web.input()
        if i.has_key('catalog') and i.catalog:
            catalog = i.catalog
        else:
            return 'You must GET the URL with parameter catalog'
        branch_list = cmdb.get_catalog_branch(catalog=catalog, env=env)
        return render.catalog_branch(catalog=catalog, branch_list=branch_list)

class ip_api:
    '''
    to list the IP addrs of a environment (from CMDB system)
    url example: http://aew.dianpingoa.com:8080/api/cmdb/ip?app=deal-service&env=beta
    '''
    def GET(self):
        i = web.input()
        if i.has_key('app') and i.app:
            app = i.app
        else:
            return 'You must GET the URL with parameter app'
        if i.has_key('env') and i.env:
            env = i.env
        else:
            return 'You must GET the URL with parameter env'
        if i.has_key('status') and i.status:
            status = i.status
        else:
            status = '在线'
        
        ret = {}
        ret['ip_list'] = cmdb.get_ip(app=app, env=env, status=status)
        return json.dumps(ret, sort_keys = True, indent = 4, separators=(',', ': '))

class ip_list_per_env:
    '''
    to list the total IPs of an environment  (from CMDB system).
    '''
    def GET(self):
        env = 'beta'
        i = web.input()
        if i.has_key('env') and i.env:
            env = i.env
        ip_list = cmdb.get_ip_list_env(env)
        return render.ip_list_per_env(env=env, ip_list=ip_list)

if __name__ == '__main__':
    app = web.application(urls, globals())
    app.run()