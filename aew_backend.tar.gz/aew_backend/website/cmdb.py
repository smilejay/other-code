#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Created on Dec 2, 2013

@author: jay
'''
import urllib
import json
import sys

reload(sys)
sys.setdefaultencoding('utf-8')

def get_catalog_branch(catalog = '信息线', env = 'beta'):
    branch_list = []
    url = 'http://cmdb.dp/cmdb/device/s?q=catalog:%s&env:%s,status=在线&facet=产品线分支' % (catalog, env)
    doc = urllib.urlopen(url.encode('utf-8'))
    data = json.loads(doc.read())
    for i in data['facet']['catalog_branch']:
        branch_list.append(i[0])
    return branch_list

def get_ip(app = 'deal-service', env = 'beta', status = '在线'):
    url = 'http://cmdb.dp/cmdb/device/s?q=app:%s,env:%s,status=%s' % (app, env, status)
    doc = urllib.urlopen(url.encode('utf-8'))
    data = json.loads(doc.read())
    ip_list = [x['private_ip'] for x in data['result'] ]
    return ip_list

def get_ip_list_env(env='beta'):
    ip_list = []
    url = 'http://cmdb.dp/cmdb/device/s?q=env:%s&facet=private_ip' % env
    doc = urllib.urlopen(url.encode('utf-8'))
    data = json.loads(doc.read())
    for i in data['facet']['private_ip']:
        ip_list.append(i[0])
#     print ip_list
    
    return ip_list

if __name__ == '__main__':
    get_catalog_branch()
    get_catalog_branch()
    get_ip_list_env()