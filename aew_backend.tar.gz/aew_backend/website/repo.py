'''
Created on Mar 17, 2014

@author: Jay <yongjie.ren@dianping.com>
'''

import web
import sys
sys.path.append("..")
from config import aew_db_config as conf

aew_db = web.database(dbn='mysql', host=conf['host'], user=conf['user'], pw=conf['password'], db=conf['database'])

def changes_by_group(group, month):
    '''
    get code line changes of a repo group in a specific month.
    '''
    ret = []
    if month:
        db_data_g = aew_db.select('monthly_changes_repo', \
                                  what='month, SUM(line_add) as line_add, MAX(modify_time) as modify_time', \
                                  where='ns_path=$group AND month=$month', vars=locals())
        db_data_p = aew_db.select('monthly_changes_repo', \
                                  what='month, line_add, modify_time, p_path', \
                                  where='ns_path=$group AND month=$month', \
                                  order='p_path', vars=locals())
        for data in db_data_g:
            result_dict = {}
            result_dict['repo'] = group
            result_dict['month'] = data.month.strftime('%Y-%m') if data.month else None
            result_dict['changes'] = data.line_add
            result_dict['update_time'] = data.modify_time
            ret.append(result_dict)
#             print ret
        for data in db_data_p:
            result_dict = {}
            result_dict['repo'] = '%s/%s' % (group, data.p_path)
            result_dict['month'] = data.month.strftime('%Y-%m') if data.month else None
            result_dict['changes'] = data.line_add
            result_dict['update_time'] = data.modify_time
            ret.append(result_dict)
    else:
        return None
    return ret

def changes_by_repo(group, project, month=None):
    '''
    get code line changes of a repo.
    '''
    ret = []
    if month:
        db_data_p = aew_db.select('monthly_changes_repo', \
                              what='month, line_add, modify_time', \
                              where='ns_path=$group AND p_path=$project AND month=$month', vars=locals())
    else:
        db_data_p = aew_db.select('monthly_changes_repo', \
                              what='month, line_add, modify_time', \
                              where='ns_path=$group AND p_path=$project', \
                              order='month DESC', vars=locals())
    for data in db_data_p:
        result_dict = {}
        result_dict['repo'] = '%s/%s' % (group, project)
        result_dict['month'] = data.month.strftime('%Y-%m') if data.month else None
        result_dict['changes'] = data.line_add
        result_dict['update_time'] = data.modify_time
        ret.append(result_dict)
#         print result_dict
    return ret

if __name__ == '__main__':
    print changes_by_group(group='info', month='2014-02-01')
#     changes_by_repo(group='info', project='dpindex-web', month='2013-12-1')