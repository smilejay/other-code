"""some config info for other programs

It includes some global variables and some database configurations.

Copyright @ 2013  Jay <yongjie.ren@dianping.com>
"""

base_url = 'git@code.dianpingoa.com'
base_dir = '/data/repo'
suffix = '.git'
force_renew = 0

# database config for GitLab <http://code.dianingoa.com/>
gitlab_db_config = {
    'user': 'gitlab_r',
    'password': 'dp!@3ER5rc6X',
    'host': '192.168.211.17',
    'port': '3306',
    'database': 'gitlabhq_production',
    'raise_on_warnings': True,
}

# database config for aew <http://aew.dianpingoa.com/>
aew_db_config = {
    'user': 'aew',
    'password': 'aewaew',
    'host': '10.1.77.11',
    'port': '3306',
    'database': 'aew',
    'raise_on_warnings': True,
}

# database config for Bugzilla <http://dbug.dianpingoa.com/>
bugzilla_db_config = {
    'user': 'root',
    'password': '12qwaszx',
    'host': '10.1.77.11',
    'port': '3306',
    'database': 'Bugzilla',
    'raise_on_warnings': True,
}

# database config for DW PV/UV data
ares_db_config = {
    'user': 'BiAlgo',
    'password': 'dp!@L3z9FD3yY',
    'host': '192.168.8.44',
    'port': '3306',
    'database': 'Bugzilla',
    'raise_on_warnings': True,
}